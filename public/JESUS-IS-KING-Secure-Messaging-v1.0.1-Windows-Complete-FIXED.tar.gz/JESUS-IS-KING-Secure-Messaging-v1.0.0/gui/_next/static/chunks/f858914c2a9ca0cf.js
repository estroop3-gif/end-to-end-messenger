__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/26701c29a040893c.js",
  "static/chunks/turbopack-d10119526a746760.js"
])
